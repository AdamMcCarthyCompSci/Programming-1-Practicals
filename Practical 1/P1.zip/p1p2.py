#My second program
print('Good morning!')
print('Vietnam!')
print('Good morning,','Vietnam!')