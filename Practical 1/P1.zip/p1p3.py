#Demonstrating blank lines
print('Adam Mccarthy''\n')
print('Carrigmore, Annmount, Glounthaune, Cork, Ireland''\n')
print('0867253976')