#Demonstrating variables
name='world.'
print('Hello, '+name)