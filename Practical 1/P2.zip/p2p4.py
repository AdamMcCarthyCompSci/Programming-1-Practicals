#Demonstrating indexing
alphabet='A','B','C','D','E'
print(alphabet[0])
print(alphabet[1])
print(alphabet[2])
print(alphabet[3])
print(alphabet[4])
print(alphabet[-5])
print(alphabet[-4])
print(alphabet[-3])
print(alphabet[-2])
print(alphabet[-1])