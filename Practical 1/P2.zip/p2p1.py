#Demonstrating multiple strings
print('Hello,','world.')