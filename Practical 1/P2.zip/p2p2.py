#Demonstrating concatenating strings
print('Hello, '+'world.')